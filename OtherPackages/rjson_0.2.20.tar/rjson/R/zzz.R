.onLoad <- function(lib, pkg)
{
	library.dynam("rjson", pkg, lib)
}